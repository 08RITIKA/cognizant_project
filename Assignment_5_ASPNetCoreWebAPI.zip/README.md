# Assignment 5 - ASP.NET Core Web API

## Objective
Hands-on implementation of ASP.NET Core 8.0 Web API features, including routing, controller setup, and endpoint handling.

## Project Structure
- Controllers
- Models
- Services
- appsettings.json

## How to Run
1. Open in Visual Studio or VS Code.
2. Run using `dotnet run`.
3. Test endpoints using Postman or Swagger.

## Skills Covered
- Web API fundamentals
- Routing
- CRUD operations
