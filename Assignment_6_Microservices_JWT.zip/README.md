# Assignment 6 - JWT Authentication in ASP.NET Core Web API

## Objective
Implement JSON Web Token (JWT) authentication for securing APIs in an ASP.NET Core Web API project.

## Features
- Login endpoint with JWT generation
- Secured endpoints with JWT Bearer Authentication
- Custom JWT service

## How to Run
1. Restore NuGet packages.
2. Update JWT settings in `appsettings.json`.
3. Run the API and test authentication using Postman.

## Skills Covered
- ASP.NET Core Web API
- JWT Bearer Token Authentication
- Middleware configuration
