# Week 1 - Cognizant Internship Hands-on Solutions

This folder contains all the mandatory hands-on coding exercises for **Week 1** of the Cognizant Internship Program.

## 📘 Topics Covered

### 1. Design Patterns and Principles

#### 🧪 Exercise 1: Singleton Pattern
This Python script demonstrates the Singleton design pattern. It ensures only one instance of a class is created during the program lifecycle.

**File:** `DesignPatterns_Singleton.py`

---

#### 🧪 Exercise 2: Factory Method Pattern
This example uses the Factory Method design pattern to return different notification types (SMS, Email) based on user input.

**File:** `DesignPatterns_Factory.py`

---

### 2. Data Structures and Algorithms

#### 🧪 Exercise 2: E-commerce Platform Search Function
This script performs a case-insensitive search over a list of product names using a simple linear search approach.

**File:** `DSA_SearchFunction.py`

---

#### 🧪 Exercise 7: Financial Forecasting (Moving Average)
Implements a basic financial forecasting algorithm using the moving average method to smooth out time series data.

**File:** `DSA_FinancialForecasting.py`

---

## ✅ Submission Instructions

- Ensure this folder is part of your GitHub public repository.
- Follow the structure: `Cognizant_Internship_Solutions/Week_1/`
- Share the repository link with your POC when asked.

---

> Prepared with ❤️ for Cognizant Internship - Week 1