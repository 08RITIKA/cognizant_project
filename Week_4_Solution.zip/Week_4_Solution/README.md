# Week 4 - Cognizant Internship Hands-on: Web API

This folder includes basic Web API exercises using Flask (Python) to simulate REST API endpoints for learning and testing.

## 🧪 Exercises:

### 1. WebApi_Handson_1.py
Create a basic `GET /` endpoint that returns a greeting message.

### 2. WebApi_Handson_2.py
Create a `GET /greet` endpoint that uses query parameters to return a personalized message.

### 3. WebApi_Handson_3.py
Implement a `POST /sum` endpoint that accepts two numbers as JSON and returns their sum.

### 4. WebApi_Handson_4.py
Simulate simple CRUD operations on items using path parameters and JSON request bodies.

### 5. WebApi_Handson_5.py
Demonstrate how to return custom status codes and handle error responses.

### 6. WebApi_Handson_6.py
Return a well-formatted JSON user profile.

---

## 🚀 How to Run

All files use Flask. Run each with:

```bash
python filename.py
```

Make sure Flask is installed:

```bash
pip install flask
```

---

> Prepared with ❤️ for Cognizant Internship - Week 4