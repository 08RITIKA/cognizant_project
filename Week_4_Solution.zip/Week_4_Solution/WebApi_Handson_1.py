"""
Exercise 1: Web API Basics
Task: Build a simple GET endpoint using Flask
"""

from flask import Flask

app = Flask(__name__)

@app.route('/')
def home():
    return "Hello from Web API - Exercise 1"

if __name__ == '__main__':
    app.run(debug=True)