"""
Exercise 3: Web API - POST Request Example
"""

from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/sum', methods=['POST'])
def sum_values():
    data = request.get_json()
    result = data['a'] + data['b']
    return jsonify({'sum': result})

if __name__ == '__main__':
    app.run(debug=True)