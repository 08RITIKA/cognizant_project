"""
Exercise 4: Web API - Basic CRUD Example
"""

from flask import Flask, request, jsonify

app = Flask(__name__)

db = {}

@app.route('/item/<string:item_id>', methods=['GET'])
def get_item(item_id):
    return jsonify({item_id: db.get(item_id, 'Not found')})

@app.route('/item/<string:item_id>', methods=['POST'])
def add_item(item_id):
    data = request.get_json()
    db[item_id] = data['value']
    return jsonify({'message': 'Item added'}), 201

if __name__ == '__main__':
    app.run(debug=True)