"""
Exercise 5: Web API - Status Codes & Error Handling
"""

from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/status')
def status():
    return jsonify({'status': 'OK'}), 200

@app.route('/error')
def error():
    return jsonify({'error': 'Something went wrong'}), 500

if __name__ == '__main__':
    app.run(debug=True)