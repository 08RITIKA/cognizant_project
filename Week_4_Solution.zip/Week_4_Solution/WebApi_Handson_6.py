"""
Exercise 6: Web API - JSON Response Format
"""

from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/user')
def user():
    return jsonify({
        'name': 'John Doe',
        'role': 'Developer',
        'email': 'john.doe@example.com'
    })

if __name__ == '__main__':
    app.run(debug=True)